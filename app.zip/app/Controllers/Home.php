<?php

namespace App\Controllers;
 

class Home extends BaseController
{
    public function index()
    {
      echo view('comman/header');
      return view('home');
      echo view('comman/footer');
    }
}
