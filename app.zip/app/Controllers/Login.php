<?php

namespace App\Controllers;
 

class Login extends BaseController
{
    public function index()
    {
      echo view('comman/header');
      echo view('login');
      echo view('comman/footer');
         
    }
}
 
