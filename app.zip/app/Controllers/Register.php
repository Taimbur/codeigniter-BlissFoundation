<?php

namespace App\Controllers;

 

 
class Register extends BaseController
{
    public function index()
    {
      echo view('comman/header');
      echo view('register');
      echo view('comman/footer');
         
    }
    
}
