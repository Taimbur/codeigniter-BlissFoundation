<?php

namespace App\Controllers;
 

class Welcome extends BaseController
{
    public function index()
    {
      echo view('comman/header');
      return view('welcome_message');
      echo view('comman/footer');
    }
}
