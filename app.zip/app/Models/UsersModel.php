<!-- class usersModel extends Model{

    protected $table='users';
    protected $primaryKey='id';

    protected $useAutoIncrement=true;

    protected $returnType='object';
    protected $useSoftDeletes=true;

    protected $allowedFields=['Name','Password','CreatedAt','UpdateAt',''];

    protected $useTimestamps=false;  
    protected $CreatedField='CreatedAt';   
    protected $UpdateField='UpdateAt';   
    protected $DeletedField='DeletedAt';

    protected $validtaionRule=[];
    protected $validtaionMessages=[];
    protected $skipValidtion=false;
   
    
} -->

<!-- for my personl use  -->