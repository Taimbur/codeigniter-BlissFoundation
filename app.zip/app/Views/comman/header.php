<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>⚡codeigniter</title>

    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-PN4B2DQ');
    </script>
    <!-- End Google Tag Manager -->


    <!-- remixIcon cdn -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.2.0/fonts/remixicon.css" rel="stylesheet">
    <!-- remixIcon cdn end here-->

    <link rel="stylesheet" href="http://localhost/code-4/assets/responsive.css">
    <link rel="stylesheet" href="http://localhost/code-4/assets/all.css">
    <link rel="stylesheet" href="http://localhost/code-4/assets/treaning.css">
    <link rel="stylesheet" href="http://localhost/code-4/assets/bootstrap.min.css">
    <link rel="stylesheet" href="http://localhost/code-4/assets/testing.css">

    <!-- bootstrap links -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous"> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
    <!-- bootstrap end -->
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PN4B2DQ" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <section>
        <header>
            <div class="header">
                <div class="row" style="margin: 6px;">
                    <div class="col-md-4 text-center" style="padding-bottom: 35px; padding-top: 30px;">
                        <div class="site-logo">
                            <a href="#" title="Ultimate Bliss
                                    Foundation" rel="home">
                                <img class="header-image" src="https://ultimatebliss.in/assets/images/trans-logo.png" alt="Ultimate Bliss Foundation" title="Ultimate Bliss Foundation" class="center" style="box-shadow:0px 1px 2px 1px grey;border-radius:50%">
                            </a>
                            <div class="content mt-3">
                                <h4 style="color:#ff0090 ;font-weight:550;font-size:1.5rem">ULTIMATE BLISS FOUNDATION</h4>
                                <p style="color:#00008B ;font-weight:bold">Wellness, Spirituality & Life Celebration Center</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="text-copy">

                            <h6>Explore Life</h6>
                            <h6 style="color:#ff0090 ">beyond death,</h6><br>
                            <h6>a Life</h6>
                            <h6 style="color:#ff0090 ;">free from all misery and sufferings,</h6><br>
                            <h6>a Life</h6>
                            <h6 style="color:#ff0090 ;">marked with Eternity, Infinity & Ultimate Bliss. </h6>

                        </div>
                    </div>

                    <div class="col-md-4 text-center" style="padding-bottom: 35px; padding-top: 26px;">
                        <div class="head-img">
                            <a href="index.php" title="Swami Aaron" rel="home">
                                <img class="header-image" src="https://ultimatebliss.in/assets/responsiveimg/logo.jpg" alt="Swami Aaron" title="Swami Aaron">
                            </a>
                            <div class="content mt-2">
                                <h5 style="margin-top: 16px;font-weight:545;color:#ff0090;">Swami Aaron
                                    <br><span style="font-size: 17px;color:#00008b ">(Dr. Aaron Thomas)</span>
                                </h5>
                                <p style="color:#ff0090 ;font-weight:bold">Author | Psychotherapist | Spiritual Master</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 head-content">
                        <div class="content text-center">
                            <h4 style="color:#ff0090 ;font-weight:550;font-size:1.5rem">WE TRANSFORM LIFE IN SUCCESS, CELEBRATION & PURE BLISS!</h4>
                        </div>
                    </div>
                </div>


                <nav class="navbar navbar-expand-lg  " style="background:#33cccc ;color:white">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="color:#000">
                            <span><i class="ri-align-justify" style="font-size: 30px;"></i></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav me-auto mb-2 mb-lg-0 text-dark" style="padding-left:15px;">
                                <li class="nav-item">
                                    <a class="nav-link active" aria-current="page" href="https://ultimatebliss.in/Ultimate/index">Home</a>
                                </li>

                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        About
                                    </a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="ultimate-bliss-foundation.php">Ultimate Bliss Foundation</a>
                                        <a class="dropdown-item dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Founder: Swami Aaron</a>
                                        <ul class="dropdown-ul subMenu">
                                            <a class="dropdown-item" href="founder.php" target="_Blank">About Swami Aaron</a>
                                            <a class="dropdown-item" href="https://ultimatebliss.in/Ultimate/swami_blog" target="_Blank">Swami Aaron’s Blogs</a>
                                            <a class="dropdown-item" href="https://anchor.fm/dr-aaron-thomas" target="_Blank">Swami Aaron’s Podcasts</a>
                                            <a class="dropdown-item" href="https://ultimatebliss.org/musings.php" target="_Blank">Swami Aaron’s Musings</a>
                                            <a class="dropdown-item" href="https://poetry.ultimatebliss.in" target="_Blank">Swami Aaron’s Poetry</a>
                                            <a class="dropdown-item" href="https://www.amazon.in/Swami-Aaron/e/B00K1TD908%3Fref=dbs_a_mng_rwt_scns_share" target="_Blank">Swami Aaron’s Books</a>
                                            <a class="dropdown-item" href="https://www.youtube.com/channel/UCknFKDDuEqRL7e3GDPRXRog" target="_Blank">Swami Aaron’s Videos</a>
                                            <a class="dropdown-item" href="https://paintings.ultimatebliss.in" target="_Blank">Swami Aaron’s Paintings</a>
                                        </ul>
                                    </div>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                                        Services
                                    </a>

                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="../treatment-counselling.php">One-to-One
                                            Sessions of Holistic Treatment, <br>
                                            Counselling, Psychotherapy & Spiritual
                                            Healing</a>
                                        <a class="dropdown-item" href="spiritual-aura.php">Creating
                                            Spiritual Aura in Family & Office Events</a>
                                        <a class="dropdown-item" href="#">Corporate Business Promotion & other Services </a>
                                        <a class="dropdown-item" href="#">Matrimonial Services</a>
                                        <a class="dropdown-item" href="#">Tour & Travel</a>
                                        <a class="dropdown-item" href="#">Hospitality</a>
                                        <a class="dropdown-item" href="#">Co-working Space</a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                                        Courses
                                    </a>

                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="../life-transformation-training.php">Life
                                            Transformation Training Programs & Workshops</a>

                                        <a class="dropdown-item" href="#">Professional Training Programs</a>
                                        <a class="dropdown-item" href="#">Residential Retreats</a>

                                        <a class="dropdown-item" href="wellness-training.php">Corporate Wellness & Training Programs
                                        </a>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="residential-retreats.php">Residential Retreats</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="workshops.php">Workshops</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="proposals.php">Proposals</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="welcome_message">Contact Us</a>
                                </li>
                            </ul>

                        </div>
                    </div>
                </nav>

            </div>
        </header>
    </section>
    <!-- 2nd section begin here -->

    <section>
        <div class="container" style="margin-top:0.5%;">
            <div class="row">
                <div class="col-md-3">
                    <div class="mob" style="color:#00008B;font-weight:550">
                        <i class=ri-whatsapp-line style='font-size:20px;color:green'></i>
                        +91 9811131102
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mails" style="color:#00008B;font-weight:550">
                        <i class=ri-mail-line style="font-size:20px;color:#00008b"></i>
                        info@UltimateBliss.org, swami.aaron@gmail.com
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="social">
                        <div id="social-display-none" class="social-header">
                            <span class="header-social-icon ">
                                <a href="https://www.facebook.com/UltimateBlissFoundation" style="color:blue; margin-left: 1px; margin-right: 1px; font-size:25px" target="_Blank"><i class="ri-facebook-fill"></i></a>

                                <a href="https://www.youtube.com/channel/UCknFKDDuEqRL7e3GDPRXRog" style="color:red; margin-left: 1px; margin-right: 1px; font-size:25px" target="_Blank"><i class="ri-youtube-line"></i></a>

                                <a href="https://www.linkedin.com/company/35512093/admin/" style="color:#0077b5; margin-left: 1px; margin-right: 1px; font-size:25px" target="_Blank"><i class="ri-linkedin-fill"></i></a>

                                <a href="https://www.linkedin.com/in/swami-aaron-57921335/" style="color:#00acee; margin-left: 1px; margin-right: 1px; font-size:25px" target="_Blank"><i class="ri-twitter-line"></i></a>

                                <a href="https://www.instagram.com/ultimatebliss.in/" style="color:#8a3ab9; margin-left: 1px; margin-right: 1px; font-size:25px" target="_Blank"><i class="ri-instagram-line "></i></a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>

</html>