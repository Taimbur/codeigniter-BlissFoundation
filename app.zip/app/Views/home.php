 <!DOCTYPE html>
 <html lang="en">

 <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Wellness, Spirituality & Life Celebration Center | ULTIMATE BLISS FOUNDATION</title>
     <meta name="description" content="Transform Your Life in Bliss & Freedom with our Holistic Treatment, Counselling, Psychotherapy and Spiritual Healing Sessions and Life Transformation Training Programs. Call or WhatsApp at +91-9810969067 for details.">
     <style>
         body,
         h1,
         h2,
         h3,
         h4,
         h5,
         div,
         p,
         section {

             line-height: 25px;
         }

         h3 {
             line-height: 25px;
         }

         h6 {
             line-height: 25px;
         }

         .flex {
             width: 100%;
             flex-direction: column;
             background-color: #000;
             justify-content: center;
             align-items: center;
             /*display: flex;*/
         }
     </style>

     <link rel="stylesheet" href="http://localhost/code-4/assets/responsive.css">

 </head>

 <body>
     <div class="container mt-4 ">

         <div class="main-headings pt-5 py-5 pl-5 pr-5">

             <figure class="text-end">
                 <blockquote class="blockquote">
                     <h6 class="h6-t">Which is the biggest happiness you have experienced in your life so far?<br><br>
                         Food? Sex? Wealth? Power? Fame? Praise? World Tour? Beautiful Nature? Love? Soulful Relationship? Well Settled Children and Relatives?<br><br>
                         I am not against all these happiness, but I can show you the path to even bigger happiness than all this as how to experience the State of Pure Awakened Silence, the Highest Consciousness, the Ultimate Intelligence, the Ultimate Bliss of Existence.<br><br>
                         Nothing of the World can match this experience of Pure Pristine Sheer Bliss!</h6>

                 </blockquote>
                 <figcaption class="blockquote-footer">
                     <cite title="Source Title">Swami Aaron (Dr. Aaron Thomas)</cite>
                 </figcaption>
             </figure>
         </div>
         <div class="container">
             <div class="row">
                 <!-- 1st blog -->
                 <div class="col-md-4 col-lg-4">
                     <div class="card" style="width: 100%;">
                         <img src="https://ultimatebliss.in/assets/responsiveimg/1.jpg" class="card-img-top" height="250h" alt="...">
                         <div class="card-body">
                             <h4 class="card-title text-center text-uppercase mt-4 mb-2" style="color:#ff0090 ;font-weight:bold;font-size:1.4rem">We cure even incurable!</h4><br>
                             <h4 class="card-title text-center" style="color:#00008b;font-weight:bld;font-size:0.9rem">One-to-One Sessions of </h4>
                             <h4 class="card-title text-center" style="color:#ff0090;font-weight:bold;font-size:1rem">HOLISTIC TREATMENT, COUNSELLING, </h4>
                             <h4 class="card-title text-center" style="color:#ff0090;font-weight:bold;font-size:1rem">PSYCHOTHERAPY & SPIRITUAL HEALING</h4>
                             <p class="card-text text-center" style="color:#00008b;font-size:1rem;font-weight:bold;font-size:1rem">for<br> Emotional Wellness, Health,<br> Relationship, Career, Finance <br>and Spiritual Growth</p>
                             <center> <a href="https://ultimatebliss.in/Ultimate/treatment_healing" style="background:#ffb300 " class="btn btn-primary btn-center mt-4 mb-2">Click for details</a></center>
                         </div>
                     </div>
                 </div>
                 <!-- 2nd blog -->
                 <div class="col-md-4 col-lg-4">
                     <div class="card" style="width: 100%;">
                         <img src="https://ultimatebliss.in/assets/responsiveimg/2.jpg" class="card-img-top" height="250h" alt="...">
                         <div class="card-body">
                             <h4 class="card-title text-center mt-4 mb-2" style="color:#ff0090 ;font-weight:bold;font-size:1.4rem">TRANSFORM LIFE IN SUCCESS & BLISS</h4>
                             <h4 class="card-title text-center" style="color:#00008b;font-weight:bold;font-size:0.9rem">with our </h4>
                             <h4 class="card-title text-center mb-4" style="color:#ff0090;font-weight:bold;font-size:1rem">LIFE TRANSFORMATION TRAINING PROGRAMS</h4><br>
                             <p class="card-text text-center" style="color:#00008b;font-weight:bold;font-size:1rem">Very powerful Scientific Programs developed by Swami Aaron (Dr. Aaron Thomas) and his team after extensive research for more than thirty years.</p>
                             <center> <a href="https://ultimatebliss.in/Ultimate/treaning" style="background:#ffb300 " class="btn btn-primary btn-center mt-2 mb-2">Click for details</a></center>
                         </div>
                     </div>
                 </div>
                 <!-- 3rd blog -->
                 <div class="col-md-4 col-lg-4 ">
                     <div class="card" style="width: 100%;">
                         <img src="https://ultimatebliss.in/assets/responsiveimg/3.jpg" class="card-img-top" height="250h" alt="...">
                         <div class="card-body">
                             <h4 class="card-title text-center mt-4 mb-2" style="color:#ff0090 ;font-weight:bold;font-size:1.4rem">TRANSFORM LIFE IN JOY & CELEBRATION </h4>
                             <h4 class="card-title text-center" style="color:#00008b;font-weight:bold;font-size:0.9rem">with our </h4>
                             <h4 class="card-title text-center mb-4" style="color:#ff0090;font-weight:bold;font-size:1rem">RESIDENTIAL RETREATS IN INDIA & ABROAD</h4>
                             <p class="card-text text-center">
                             <ol>
                                 <li style="font-size:1rem;color:#00008b;font-weight:bold;font-size:1rem">Focus on Practical Realization</li>
                                 <li style="font-size:1rem;color:#00008b;font-weight:bold;font-size:1rem"> Very hygienic and comfortable accommodation with High-Speed Wi-Fi Facility</li>
                                 <li style="font-size:1rem;color:#00008b;font-weight:bold;font-size:1rem"> Hygienic, nutritious and delicious food served</li>
                                 <!-- <li  style="font-size:0.9rem;color:#00008b;"> 	Expert Medical Care, if required, provided</li> -->
                             </ol>
                             </p>
                             <center> <a href="https://ultimatebliss.in/Ultimate/residential_retreats" style="background:#ffb300 " class="btn btn-primary btn-center mt-2 mb-2">Click for details</a></center>
                         </div>
                     </div>
                 </div>

             </div>
             <!-- 2nd Thought -->
             <div class="main-headings pt-5 py-5 pl-5 pr-5">

                 <figure class="text-end">
                     <blockquote class="blockquote">
                         <h6 class="h6-t">If one doesn’t know oneself thoroughly, one’s inner self and the most importantly one’s Ultimate Self, one can never know others also even if others have been living with the person under the same roof for years and years.<br><br>
                             The Realisation of Ultimate Self is the biggest possible achievement of life because it opens the Golden Gate to Eternal Infinite Life inherent with Ultimate Bliss.
                         </h6>
                     </blockquote>
                     <figcaption class="blockquote-footer">
                         <cite title="Source Title">Swami Aaron</cite>
                     </figcaption>
                 </figure>
             </div>

             <!-- 9blogs in slidng -->
             <h1 class="my-3 text-center">OUR GLOBAL PLATFORMS</h1>
             <div id="carouselExampleDark" class="carousel carousel-dark slide">
                 <div class="carousel-indicators">
                     <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                     <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
                     <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
                 </div>
                 <div class="carousel-inner">
                     <div class="carousel-item active" data-bs-interval="10000">
                         <div class="row">
                             <div class="col">
                                 <img src="https://ultimatebliss.in/assets/responsiveimg/5.jpg" class="d-block w-100 p-5 slide-img" alt="qawali">>
                                 <div class="carousel-caption d-none d-md-block">
                                     <h5 class="text-white mb-3 bg-dark">Ultimate Bliss Life Celebration Temple</h5>
                                 </div>
                             </div>
                             <div class="col">
                                 <img src="http://localhost/code-4/assets/img/9 Ultimate Bliss Global Commune.jpg" class="d-block w-100 p-5 slide-img" alt="prty">
                                 <div class="carousel-caption d-none d-md-block">
                                     <h5 class="text-white mb-3 bg-dark">Ultimate Bliss Global Commune (UBGC)</h5>
                                 </div>
                             </div>
                         </div>
                     </div>

                     <div class="carousel-item" data-bs-interval="1000">
                         <div class="row">
                             <div class="col">
                                 <img src="http://localhost/code-4/assets/img/10 Ultimate Bliss Senior Citizen Forum.jpg" class="d-block w-100 p-5 slide-img" alt="prty">
                                 <div class="carousel-caption d-none d-md-block">
                                     <h5 class="text-white mb-3 bg-dark">Ultimate Bliss Senior Citizen Forum</h5>
                                 </div>
                             </div>
                             <div class="col">
                                 <img src="http://localhost/code-4/assets/img/9 Ultimate Bliss Global Commune.jpg" class="d-block w-100 p-5 slide-img" alt="prty">
                                 <div class="carousel-caption d-none d-md-block">
                                     <h5 class="text-white mb-3 bg-dark">Ultimate Bliss Global Monastry</h5>
                                 </div>
                             </div>
                         </div>
                     </div>

                 </div>
                 <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
                     <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                     <span class="visually-hidden">Previous</span>
                 </button>
                 <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
                     <span class="carousel-control-next-icon" aria-hidden="true"></span>
                     <span class="visually-hidden">Next</span>
                 </button>
             </div>


             <div class="main-headings pt-5 py-5 pl-5 pr-5 my-5">

                 <figure class="text-end">
                     <blockquote class="blockquote">
                         <h6 class="h6-t"> “When we live our life on the basis of perceptions and understanding created by conditioned mind and unrealized beliefs, we live life of a prisoner and fail to enjoy the glory of truth, freedom and pure bliss.”
                         </h6>

                     </blockquote>
                     <figcaption class="blockquote-footer">
                         <cite title="Source Title">Swami Aaron</cite>
                     </figcaption>
                 </figure>
             </div>


             <!--7 sliding blogs with border all around under one common heading-->
             <div class="nk-heading">
                 <a href="">Ultimate Bliss Corporate World</a>
             </div>
             <div class="container mt-5 top-news pt-5 pb-5 pl-5 pr-5">

                 <!-- <p class="text-center text-uppercase" >Ultimate Bliss Corporate World</p> -->
                 <div class="row py-3 pl-3 pr-3 pt-3 ">
                     <div class="col-md-6 slide7All mt-3">
                         <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                             <div class="carousel-inner">
                                 <div class="carousel-item active">
                                     <img src="https://ultimatebliss.in/assets/images/Corporate-Wellness-&-Training-Programs.jpg" class="d-block" alt="...">
                                     <div class="nk-title">
                                         <a href="https://ultimatebliss.in/Ultimate/corporate_treaning">Corporate Wellness & Training Programs</a>
                                     </div>
                                     <!--<center> <a href="#" style="background:#ffb300 " class="btn btn-primary btn-center mt-1 mb-5">Click for details</a></center>-->
                                 </div>

                                 <div class="carousel-item">
                                     <img src="https://ultimatebliss.in/assets/images/slide2.jpg" class="d-block" alt="...">
                                     <div class="nk-title">
                                         <a href="https://ultimatebliss.in/Ultimate/TreaningProgram">Training Programs for Jobs & Career</a>
                                     </div>
                                     <!--<center> <a href="#" style="background:#ffb300 " class="btn btn-primary btn-center mt-1 mb-5">Click for details</a></center>-->
                                 </div>
                                 <div class="carousel-item">
                                     <img src="https://ultimatebliss.in/assets/images/640.jpg" class="d-block" alt="...">
                                     <div class="nk-title">
                                         <a href="https://ultimatebliss.in/Ultimate/business_promotion">Ultimate Bliss Business Promotion Services</a>
                                     </div>
                                     <!--<center> <a href="#" style="background:#ffb300 " class="btn btn-primary btn-center mt-1 mb-5">Click for details</a></center>-->
                                 </div>
                                 <div class="carousel-item">
                                     <img src="https://ultimatebliss.in/assets/images/hos.jpg" class="d-block" alt="...">
                                     <div class="nk-title">
                                         <a href="">Ultimate Bliss Hospitality</a>
                                     </div>
                                     <!--<center> <a href="#" style="background:#ffb300 " class="btn btn-primary btn-center mt-1 mb-5">Click for details</a></center>-->
                                 </div>
                                 <div class="carousel-item">
                                     <img src="https://ultimatebliss.in/assets/images/cdd.png" class="d-block" alt="...">
                                     <div class="nk-title">
                                         <a href="https://ultimatebliss.in/Ultimate/coworkerspace">Ultimate Bliss Co-Working Space</a>
                                     </div>
                                     <!--<center> <a href="#" style="background:#ffb300 " class="btn btn-primary btn-center mt-5 mb-5">Click for details</a></center>-->
                                 </div>
                                 <div class="carousel-item">
                                     <img src="https://ultimatebliss.in/assets/images/640by.jpg" class="d-block" alt="...">
                                     <div class="nk-title">
                                         <a href="https://ultimatebliss.in/Ultimate/priveledge_mtrimony">Ultimate Bliss Privileged Matrimony</a>
                                     </div>
                                     <!--<center> <a href="#" style="background:#ffb300 " class="btn btn-primary btn-center mt-5 mb-5">Click for details</a></center>-->
                                 </div>
                                 <div class="carousel-item">
                                     <img src="https://ultimatebliss.in/assets/images/12.png" class="d-block" alt="...">
                                     <div class="nk-title">
                                         <a href="https://ultimatebliss.in/Ultimate/ultimateblisshome">Ultimate Bliss Home Stay</a>
                                     </div>
                                     <!--<center> <a href="#" style="background:#ffb300 " class="btn btn-primary btn-center mt-5 mb-5">Click for details</a></center>-->
                                 </div>
                             </div>
                             <button class="carousel-control-prev" type="button" data-target="#carouselExampleControls" data-slide="prev">
                                 <span class="carousel-control-prev-icon1 text-black" aria-hidden="true"></span>
                                 <span class="sr-only">Previous</span>
                             </button>
                             <button class="carousel-control-next" type="button" data-target="#carouselExampleControls" data-slide="next">
                                 <span class="carousel-control-next-icon1" aria-hidden="true"></span>
                                 <span class="sr-only">Next</span>
                             </button>
                         </div>
                     </div>
                     <div class="col-md-6 SlideSingle">
                         <div class="row">
                             <div class="col-md-6 mt-3">
                                 <img src="https://ultimatebliss.in/assets/images/Corporate-Wellness-&-Training-Programs.jpg" width="100%" height="140" class="d-block" alt="...">
                                 <div class="nk-titles">
                                     <a href="https://ultimatebliss.in/Ultimate/corporate_treaning">Corporate Wellness & Training Programs</a>
                                 </div>
                             </div>
                             <div class="col-md-6 mt-3">
                                 <img src="https://ultimatebliss.in/assets/images/slide2.jpg" width="100%" height="130" class="d-block" alt="...">
                                 <div class="nk-titles">
                                     <a href="https://ultimatebliss.in/Ultimate/TreaningProgram">Training Programs for Jobs & Career</a>
                                 </div>
                             </div>
                             <div class="col-md-6 mt-3">
                                 <img src="https://ultimatebliss.in/assets/images/640.jpg" width="100%" height="130" class="d-block" alt="...">
                                 <div class="nk-titles">
                                     <a href="https://ultimatebliss.in/Ultimate/business_promotion">Ultimate Bliss Business Promotion Services</a>
                                 </div>
                             </div>
                             <div class="col-md-6 mt-3">
                                 <img src="https://ultimatebliss.in/assets/images/hos.jpg" width="100%" height="130" class="d-block" alt="...">
                                 <div class="nk-titles">
                                     <a href="">Ultimate Bliss Hospitality</a>
                                 </div>
                             </div>
                             <div class="col-md-6 mt-3">
                                 <img src="https://ultimatebliss.in/assets/images/cdd.png" width="100%" height="130" class="d-block" alt="...">
                                 <div class="nk-titles">
                                     <a href="https://ultimatebliss.in/Ultimate/coworkerspace">Ultimate Bliss Co-Working Space</a>
                                 </div>
                             </div>
                             <div class="col-md-6 mt-3">
                                 <img src="https://ultimatebliss.in/assets/images/12.png" width="100%" height="130" class="d-block" alt="...">
                                 <div class="nk-titles">
                                     <a href="https://ultimatebliss.in/Ultimate/ultimateblisshome">Ultimate Bliss Home Stay</a>
                                 </div>
                             </div>
                             <div class="col-md-12 mt-3">
                                 <img src="https://ultimatebliss.in/assets/images/640by.jpg" width="100%" height="130" class="d-block" alt="...">
                                 <div class="nk-titless">
                                     <a href="https://ultimatebliss.in/Ultimate/priveledge_mtrimony">Ultimate Bliss Privileged Matrimony</a>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>

                 <div class="row">
                     <!-- 1st blog -->
                     <div class="col-md-4 col-lg-4">
                         <div class="card" style="width: 100%;">
                             <img src="https://ultimatebliss.in/assets/responsiveimg/14.jpg" class="card-img-top" height="250h" alt="...">
                             <div class="card-body">
                                 <h4 class="card-title text-center text-uppercase  mt-3 mb-3" style="color:#ff0090;font-size:1.5rem;font-weight:bold">Speak Your Heart & Soul</h4>
                                 <p class="card-text text-center" style="color:#00008b;font-size:1rem;font-weight:bold ">Take the first step towards Liberation & Freedom!.</p>
                                 <center> <a href="https://ultimatebliss.in/Ultimate/heart_soul" style="background:#ffb300 " class="btn btn-primary btn-center mt-3 mb-3">Click for details</a></center>
                             </div>
                         </div>
                     </div>
                     <div class="col-md-4 col-lg-4">
                         <div class="card" style="width: 100%;">
                             <img src="https://ultimatebliss.in/assets/responsiveimg/15.jpg" class="card-img-top" height="250h" alt="...">
                             <div class="card-body">
                                 <h4 class="card-title text-center text-uppercase  mt-3 mb-3" style="color:#ff0090;font-size:1.4rem;font-weight:bold">Conscious Citizen Forum & Social Issues</h4>
                                 <p class="card-text text-center mb-5" style="color:#00008b;font-size:1rem;font-weight:bold">Let us rise against social problems!</p>
                                 <center> <a href="https://ultimatebliss.in/Ultimate/conscious_citizen_forum" style="background:#ffb300 " class="btn btn-primary btn-center mt-4 mb-3">Click for details</a></center>
                             </div>
                         </div>
                     </div>
                     <div class="col-md-4 col-lg-4">
                         <div class="card" style="width: 100%;">
                             <img src="https://ultimatebliss.in/assets/responsiveimg/15.jpg" class="card-img-top" height="250h" alt="...">
                             <div class="card-body">
                                 <h4 class="card-title text-center text-uppercase  mt-3 mb-3" style="color:#ff0090;font-size:1.4rem;font-weight:bold">Volunteers Invited for Social Change</h4>
                                 <p class="card-text text-center" style="color:#00008b;font-size:1rem;font-weight:bold">Let us bring smile on the face of Humanity!</p>
                                 <center> <a href="https://ultimatebliss.in/Ultimate/volunteers_invited" style="background:#ffb300 " class="btn btn-primary btn-center mt-3 mb-3">Click for details</a></center>
                             </div>
                         </div>
                     </div>
                 </div>



             </div>
             <!-- <section class="container spacing"style="margin-bottom: 5rem;">
 <div class="container">
                 <div class="row">
                    <div class="col-4-md">
                    <div class="container card" style="box-shadow:0px 1px 2px 2px black">
                    <div class="row eight-button">
                        <div class="col-md-3 text-center">
                            <div class="dr-img">
                                <a href="index.html" title="Swami Aaron" rel="home">
                                    <img class="header-image" src="https://ultimatebliss.in/assets/images/head.jpeg" alt="Swami Aaron" title="Swami Aaron">
                                </a>
                                <div class="content">
                                    <h4 style="color:#ff0090; margin-top:10px;font-size:1.4rem;font-weight:bold">Swami Aaron
                                        <br>(Dr. Aaron Thomas)
                                    </h4>
                                    <p style="color:#00008b; font-size: 11px; margin-bottom:0px;font-weight:650;line-height:10px">Author | Psychotherapist |
                                        Spiritual Master</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-9" style="margin:auto;">
                            <div class="six-section-two">
                                <h4 class="six-section-h4" style="color:#ff0090;font-size:1.1rem;">Explore the profound dimensions of life with Swami Aaron’s
                                    Knowledge, Creativity & Wisdom
                                </h4>
                                <div class="six-container">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <ul class="list-group list-group-horizontal">
                                                <a href="https://ultimatebliss.in/Ultimate/swami_blog" class="btn morebtn" target="_Blank">Swami Aaron’s Blogs</a>
                                                <a href="https://poetry.ultimatebliss.in" class="btn morebtn" target="_Blank"> Swami Aaron’s Poetry</a>
                                                <a href="https://paintings.ultimatebliss.in" class="btn morebtn" target="_Blank">Swami Aaron’s Paintings</a>
                                                <a href="https://ultimatebliss.org/musings.php" class="btn morebtn" target="_Blank"> Swami Aaron’s Musings</a>
                                            </ul>
                                        </div>
                                        <div class="col-md-12">
                                            <ul class="list-group list-group-horizontal">
                                                <a href="https://www.youtube.com/channel/UCknFKDDuEqRL7e3GDPRXRog" class="btn morebtn" target="_Blank"> Swami Aaron’s Videos</a>
                                                <a href="https://anchor.fm/dr-aaron-thomas" class="btn morebtn" target="_Blank">Swami Aaron’s Podcasts</a>
                                                <a href="https://www.amazon.in/Swami-Aaron/e/B00K1TD908%3Fref=dbs_a_mng_rwt_scns_share" class="btn morebtn" target="_Blank"> Swami Aaron’s Books</a>
                                                <a href="https://ultimatebliss.org/founder-swami-aaron.php" class="btn morebtn" target="_Blank"> Swami Aaron’s Love</a>
                                            </ul>
                                        </div>
                                    </div>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                    </div>
                    <div class="col-md-8"></div>
                 </div>
              </div>
            </section> -->

             <section class="container spacing">
                 <div class="container">
                     <div class="row ">
                         <div class="col-md-6 mt-3">
                             <div class="card text-center">
                                 <div class="dr-img mt-5">
                                     <a href="#" title="Swami Aaron" rel="home">
                                         <img class="header-image" src="https://ultimatebliss.in/assets/responsiveimg/logo.jpg" alt="Swami Aaron" title="Swami Aaron" style="width:200px;height:170px">
                                     </a>
                                     <div class="content pt-4">
                                         <h4 style="color:#ff0090; margin-top:10px;font-size:1.6rem;font-weight:bold">Swami Aaron
                                             <br>(Dr. Aaron Thomas)
                                         </h4>
                                         <p style="color:#00008b; font-size: 17px; margin-bottom:0px;font-weight:650;line-height:10px" class="mt-2">Author | Psychotherapist |
                                             Spiritual Master</p>
                                     </div>
                                 </div>

                                 <div class="six-section-two pt-3">
                                     <h4 class="six-section-h4 mt-5 mb-3" style="color:#ff0090;font-size:1.3rem;line-height:35px">Explore the profound dimensions of life with Swami Aaron’s
                                         Knowledge, Creativity & Wisdom
                                     </h4>
                                     <div class="six-container" style="padding-top:2rem">
                                         <div class="row">
                                             <div class="col-md-12">
                                                 <ul class="list-group list-group-horizontal">
                                                     <a href="https://ultimatebliss.in/Ultimate/swami_blog" class="btn morebtn" target="_Blank">Swami Aaron’s Blogs</a>
                                                     <a href="https://poetry.ultimatebliss.in" class="btn morebtn" target="_Blank"> Swami Aaron’s Poetry</a>
                                                 </ul>
                                             </div>
                                             <div class="col-md-12">
                                                 <ul class="list-group list-group-horizontal">
                                                     <a href="https://paintings.ultimatebliss.in" class="btn morebtn" target="_Blank">Swami Aaron’s Paintings</a>
                                                     <a href="https://ultimatebliss.org/musings.php" class="btn morebtn" target="_Blank"> Swami Aaron’s Musings</a>
                                                 </ul>
                                             </div>
                                             <div class="col-md-12">
                                                 <ul class="list-group list-group-horizontal">
                                                     <a href="https://www.youtube.com/channel/UCknFKDDuEqRL7e3GDPRXRog" class="btn morebtn" target="_Blank"> Swami Aaron’s Videos</a>
                                                     <a href="https://anchor.fm/dr-aaron-thomas" class="btn morebtn" target="_Blank">Swami Aaron’s Podcasts</a>
                                                 </ul>
                                             </div>
                                             <div class="col-md-12">
                                                 <ul class="list-group list-group-horizontal">
                                                     <a href="https://www.amazon.in/Swami-Aaron/e/B00K1TD908%3Fref=dbs_a_mng_rwt_scns_share" class="btn morebtn" target="_Blank"> Swami Aaron’s Books</a>
                                                     <a href="https://ultimatebliss.org/founder-swami-aaron.php" class="btn morebtn" target="_Blank"> Swami Aaron’s Love</a>
                                                 </ul>
                                             </div>
                                         </div>
                                         <!--</button>-->
                                     </div>
                                 </div>
                             </div>
                         </div>
                         <div class="col-md-6 mt-3">
                             <div class="first-image">
                                 <img src="https://ultimatebliss.in/assets/responsiveimg/17.jpg" width="100%" height="400px">
                             </div>
                             <div class="first-image">
                                 <h3 class="text-center mt-5 mb-5 text-uppercase" style="color:#ff0090;font-size:1.9rem;font-weight:bold">SWAMI AARON'S PAINTINGS</h3>
                                 <img src="https://ultimatebliss.in/assets/responsiveimg/18.jpg" width="100%" height="200px">
                             </div>
                         </div>
                     </div>
                 </div>
             </section>


             <div class="container" style="background:#ebfbcd;">
                 <div class="content">
                     <div class="row">
                         <div class="col-md-4 col-lg-4">
                             <h3 class="text-center mt-4 mb-1 text-uppercase" style="color:#ff0090;font-size:1.9rem;font-weight:bold">Swami Aaron’s Blogs</h3>
                             <div class="cards" style="width: 100%;">
                                 <div class="card-body">
                                     <ol>
                                         <li>What does Life mean to you?</li>
                                         <li>Would you dance with me in rain of Bliss?</li>
                                         <li>Do you really live your life? Or your life lives you? Do you really know yourself?</li>
                                         <li>Why are most of women not very happy in their marital Life?</li>
                                         <li>Why are you just a Hindu, Muslim or a Christian?</li>
                                         <li> Do we have fixed destiny? Or We have Free Will? Determinism v/s Free will: Astrology and Beyond</li>
                                         <li>Ultimate Goal of Human Life</li>
                                         <li>Recognition of True Love</li>
                                         <li>Making sex divine with Consciousness</li>
                                         <li>Laugh your heart & soul</li>
                                     </ol>
                                 </div>
                             </div>
                         </div>
                         <div class="col-md-3 col-lg-3">
                             <h3 class="text-center mt-4 mb-1 text-uppercase" style="color:#ff0090;font-size:1.8rem;font-weight:bold;">Swami Aaron’s Poetry</h3>
                             <div class="cards" style="width: 100%;">
                                 <div class="card-body">
                                     <ol>
                                         <li>Buddha smiles in Eternity</li>
                                         <li>Sitting atop the mountain hill</li>
                                         <li>Dance of Silence</li>
                                         <li>Nirvana</li>
                                         <li>As you smile</li>
                                         <li>Your silence screams</li>
                                         <li>When silence seeps inside me</li>
                                         <li>I Love You Despite Your Hatred</li>
                                         <li>Waiting for my Lady love</li>
                                         <li>Unlived Life</li>
                                     </ol>
                                 </div>
                             </div>
                         </div>
                         <div class="col-md-5 col-lg-5">
                             <h3 class="text-center mt-4 mb-1 text-uppercase" style="color:#ff0090;font-size:1.8rem;font-weight:bold;"> Upcoming Social <br>Projects</h3>
                             <div class="cards" style="width: 100%;">
                                 <div class="card-body">
                                     <ol>
                                         <li>Ultimate Bliss Home for Senior Citizens</li>
                                         <li>Ultimate Bliss Home for Under-privileged Students</li>
                                         <li>Ultimate Bliss Rehabilitation Centre</li>
                                         <li>Ultimate Bliss Home for Working Men & Women</li>
                                         <li>Skill Training Centre for Underprivileged Youth</li>
                                         <li>Ultimate Bliss Life Celebration Village</li>
                                         <li>Nutri-Meal Projects for Urban Employment</li>
                                         <li>Ultimate Bliss Life Celebration Temple</li>
                                         <li>Community Agriculture</li>
                                         <li>Community Insurance: Agricultural Crops Insurance, Health Insurance, Life Insurance</li>
                                         <li>Community Small Scale Industry</li>
                                         <li>Centre for Education of Under-privileged Children & Adults</li>
                                     </ol>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
             <!-- swami aron's Vedio -->

             <section>
                 <div class="elevin-section container ">
                     <div class="youtube-section-one">

                         <h2 class="elevin-h1" style="color:#ff0090"> Swami Aaron’s Videos</h2>
                         <div class="row">
                             <!-- <div class="col-md-1"></div> -->
                             <div class="col-md-12">
                                 <iframe width="100%" height="400" src="https://www.youtube.com/embed/q69X1udWov8?autoplay=1&mute=0">
                                 </iframe>
                             </div>
                             <div class="col-md-12">
                                 <div class="video-content">
                                     <h4 style="color:#ff0090;font-size:1.4rem;font-weight:bold" class="text-center">Ontology Of All Problems and Misery: Freedom from All Problems of Life - Introductory Session</h54>
                                         <center>
                                             <div class="watch-btn mt-5" style="padding:15px 0px; margin-top: auto;">
                                                 <a href="https://www.youtube.com/embed/q69X1udWov8?autoplay=1&mute=0" class="btn" style="margin-top: auto;color:#00008b" target="_Blank">Watch Video</a>
                                         </center>
                                 </div>
                             </div>
                         </div>

                     </div>

                 </div>

                 <div class="youtube-section-one">

                     <h2 class="elevin-h1" style="color:#ff0090">Swami Aaron’s Videos</h2>

                     <div class="row">
                         <!-- <div class="col-md-1"></div> -->

                         <div class="col-md-12">
                             <iframe width="100%" height="400" src="https://www.youtube.com/embed/wi4-3vHdgQE?autoplay=1&mute=">
                             </iframe>
                         </div>
                         <div class="col-md-12">
                             <div class="video-content">
                                 <h4 style="color:#ff0090;font-size:1.4rem;font-weight:bold" class="text-center">Be aware of wrong Meditation practices!</h4>
                                 <center>
                                     <div class="watch-btn mt-5" style="padding:15px 0px; margin-top: auto;">
                                         <a href="https://www.youtube.com/embed/wi4-3vHdgQE?autoplay=1&mute=1" class="btn" style="margin-top: auto;color:#00008B" target="_Blank">Watch Video</a>
                                 </center>
                             </div>
                         </div>
                     </div>
                 </div>

         </div>

         <div class="youtube-section-one">

             <h2 class="elevin-h1" style="color:#ff0090">Swami Aaron’s Videos</h2>

             <div class="row">
                 <!-- <div class="col-md-1"></div> -->
                 <div class="col-md-12">
                     <iframe width="100%" height="400" src="https://www.youtube.com/embed/dkhUfdH888M?autoplay=1&mute=1">
                     </iframe>
                 </div>
                 <div class="col-md-12">
                     <div class="video-content">
                         <h4 style="color:#ff0090;font-size:1.4rem;font-weight:bold" class="text-center">DOES SPIRITUAL HEALING WORK?</h4>
                         <center>
                             <div class="watch-btn mt-5" style="padding:15px 0px; margin-top: auto;">
                                 <a href="https://www.youtube.com/embed/dkhUfdH888M?autoplay=1&mute=1" class="btn" style="margin-top: auto;color:#00008b" target="_Blank">Watch Video</a>
                         </center>
                     </div>
                 </div>
             </div>

         </div>

     </div>

     <div class="youtube-section-one">

         <h2 class="elevin-h1" style="color:#ff0090">Swami Aaron’s Videos</h2>

         <div class="row">
             <!-- <div class="col-md-1"></div> -->
             <div class="col-md-12">
                 <iframe width="100%" height="400" src="https://www.youtube.com/embed/hInC7ENQbD4?autoplay=1&mute=1">
                 </iframe>
             </div>
             <div class="col-md-12">
                 <div class="video-content">
                     <h4 style="color:#ff0090;font-size:1.4rem;font-weight:bold" class="text-center">Are we predestined or we have freedom to exercise our freewill?</h4>
                     <center>
                         <div class="watch-btn mt-5" style="padding:15px 0px; margin-top: auto;">
                             <a href="https://www.youtube.com/embed/hInC7ENQbD4?autoplay=1&mute=1" class="btn" style="margin-top: auto;color:#00008b" target="_Blank">Watch Video</a>
                         </div>
                     </center>
                 </div>
             </div>

         </div>

     </div>

     <div class="youtube-section-one">

         <h2 class="elevin-h1" style="color:#ff0090">Swami Aaron’s Videos</h2>

         <div class="row">
             <!-- <div class="col-md-1"></div> -->
             <div class="col-md-12">
                 <iframe width="100%" height="400" src="https://www.youtube.com/embed/pwWVaETaJSY?autoplay=1&mute=1">
                 </iframe>
             </div>
             <div class="col-md-12">
                 <div class="video-content">
                     <h4 style="color:#ff0090;font-size:1.4rem;font-weight:bold" class="text-center">Why does relationship fail and become very painful sometimes?</h4>
                     <center>
                         <div class="watch-btn mt-5" style="padding:15px 0px; margin-top: auto;">
                             <a href="https://www.youtube.com/embed/pwWVaETaJSY?autoplay=1&mute=1" class="btn" style="margin-top: auto;color:#00008b" target="_Blank">Watch Video</a>
                         </div>
                     </center>
                 </div>
             </div>

         </div>

     </div>

     <div class="youtube-section-one">

         <h2 class="elevin-h1" style="color:#ff0090">Swami Aaron’s Videos</h2>

         <div class="row">
             <!-- <div class="col-md-1"></div> -->
             <div class="col-md-12">
                 <iframe width="100%" height="400" src="https://www.youtube.com/embed/lpWLH-8U2WM?autoplay=1&mute=1">
                 </iframe>
             </div>
             <div class="col-md-12">
                 <div class="video-content">
                     <h4 style="color:#ff0090;font-size:1.4rem;font-weight:bold" class="text-center">Why most of women are not very happy and satisfied in their marital life? Part 1</h4>
                     <center>
                         <div class="watch-btn mt-5" style="padding:15px 0px; margin-top: auto;">
                             <a href="https://www.youtube.com/embed/lpWLH-8U2WM?autoplay=1&mute=1" class="btn" style="margin-top: auto;color:#00008b" target="_Blank">Watch Video</a>
                         </div>
                     </center>
                 </div>
             </div>

         </div>

     </div>

     <div class="youtube-section-one">

         <h2 class="elevin-h1" style="color:#ff0090">Swami Aaron’s Videos</h2>

         <div class="row">
             <!-- <div class="col-md-1"></div> -->
             <div class="col-md-12">
                 <iframe width="100%" height="400" src="https://www.youtube.com/embed/DydxDqehvCk?autoplay=1&mute=1">
                 </iframe>
             </div>
             <div class="col-md-12">
                 <div class="video-content">
                     <h4 style="color:#ff0090;font-size:1.4rem;font-weight:bold" class="text-center">Ontology of Self: Who am I? The Golden Gate to Infinite & Eternal Life</h4>
                     <center>
                         <div class="watch-btn mt-5" style="padding:15px 0px; margin-top: auto;">
                             <a href="https://www.youtube.com/embed/DydxDqehvCk?autoplay=1&mute=1" class="btn" style="margin-top: auto;color:#00008b" target="_Blank">Watch Video</a>
                         </div>
                     </center>
                 </div>
             </div>

         </div>

     </div>

     <div class="youtube-section-one">

         <h2 class="elevin-h1" style="color:#ff0090">Swami Aaron’s Videos</h2>

         <div class="row">
             <!-- <div class="col-md-1"></div> -->
             <div class="col-md-12">
                 <iframe width="100%" height="400" src="https://www.youtube.com/embed/uc1r_mW5Qt4?autoplay=1&mute=1">
                 </iframe>
             </div>
             <div class="col-md-12">
                 <div class="video-content">

                     <h4 style="color:#ff0090;font-size:1.4rem;font-weight:bold" class="text-center">Actual Meaning of OM, Ram and Allah in English</h4>
                     <center>
                         <div class="watch-btn mt-5" style="padding:15px 0px; margin-top: auto;">
                             <a href="https://www.youtube.com/embed/uc1r_mW5Qt4?autoplay=1&mute=1" class="btn" style="margin-top: auto;color:#00008b" target="_Blank">Watch Video</a>
                         </div>
                     </center>
                 </div>
             </div>

         </div>

     </div>


     <div class="dotdown" style="text-align:center">

         <span class="dot"></span>
         <span class="dot"></span>
         <span class="dot"></span>
         <span class="dot"></span>
         <span class="dot"></span>
         <span class="dot"></span>
         <span class="dot"></span>
         <span class="dot"></span>

     </div>

     </div>


     </section>

     <div class="nk-head">
         <a href="" class="text-center">our Upcoming Services & Business Projects</a>
     </div>


     <div class="container  slide4 py-5 pl-5 pr-5 pt-5">


         <div class="row py-3 pl-3 pr-3 pt-3">
             <div class="col-md-7 mt-3">
                 <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                     <div class="carousel-inner">
                         <div class="carousel-item active">
                             <img src="https://ultimatebliss.in/assets/images/slide1.jpg" class="d-block" alt="...">
                             <div class="nk-slide">
                                 <a href="">Ultimate Bliss Curative Food & Cuisines</a>
                             </div>
                         </div>
                         <div class="carousel-item">
                             <img src="https://ultimatebliss.in/assets/images/slide2.jpg.png" class="d-block" alt="...">
                             <div class="nk-slide">
                                 <a href="">Ultimate Bliss World of Fashion</a>
                             </div>
                         </div>
                         <div class="carousel-item">
                             <img src="https://ultimatebliss.in/assets/images/slide3.jpg" class="d-block" alt="...">
                             <div class="nk-slide">
                                 <a href="">Ultimate Bliss Exotic Tour & Travel</a>
                             </div>
                         </div>
                         <div class="carousel-item">
                             <img src="https://ultimatebliss.in/assets/images/slide4.jpg.png" class="d-block" alt="...">
                             <div class="nk-slide">
                                 <a href="">UUltimate Bliss Caffe</a>
                             </div>
                         </div>
                     </div>
                     <button class="carousel-control-prev" type="button" data-target="#carouselExampleControls" data-slide="prev">
                         <span class="carousel-control-prev-icon text-black" aria-hidden="true"></span>
                         <span class="sr-only">Previous</span>
                     </button>
                     <button class="carousel-control-next" type="button" data-target="#carouselExampleControls" data-slide="next">
                         <span class="carousel-control-next-icon" aria-hidden="true"></span>
                         <span class="sr-only">Next</span>
                     </button>
                 </div>
             </div>
             <div class="col-md-5">
                 <div class="row image1">
                     <div class="col-md-6 mt-4">
                         <img src="https://ultimatebliss.in/assets/images/slide1.jpg" alt="...">
                         <div class="nk-slidep">
                             <a href="">Ultimate Bliss Curative Food & Cuisines</a>
                         </div>

                     </div>
                     <div class="col-md-6 mt-4">
                         <img src="https://ultimatebliss.in/assets/images/slide2.jpg.png" alt="...">
                         <div class="nk-slidep">
                             <a href="">Ultimate Bliss World of Fashion</a>
                         </div>

                     </div>
                     <div class="col-md-6 mt-4">
                         <img src="https://ultimatebliss.in/assets/images/slide3.jpg" alt="...">
                         <div class="nk-slidep">
                             <a href="">Ultimate Bliss Exotic Tour & Travel</a>
                         </div>

                     </div>
                     <div class="col-md-6 mt-4">
                         <img src="https://ultimatebliss.in/assets/images/slide4.jpg.png" alt="...">
                         <div class="nk-slidep">
                             <a href="">Ultimate Bliss Caffe</a>
                         </div>

                     </div>
                 </div>
             </div>
         </div>
     </div>


     <!-- 5th Thought -->
     <div class="container">
         <div class="main-heading pt-5 pb-5 pl-5 pr-5">
             <h6>
                 “Intrinsic richness of life is the only real richness because it enhances the quality of our Consciousness through which we perceive the actual reality.” Swami Aaron (Dr. Aaron Thomas)
             </h6>
         </div>

         <div class="row">
             <!-- 1st blog -->
             <div class="col-md-6 col-lg-6">
                 <div class="card" style="width: 100%;">
                     <img src="https://ultimatebliss.in/assets/responsiveimg/19.jpg" class="card-img-top" height="250h" alt="...">
                     <div class="card-body">
                         <h4 class="card-title text-center text-uppercase mt-3 mb-5" style="color:#ff0090;font-size:1.4rem;font-weight:bold">Investors invited for our projects</h4>
                         <p class="card-text text-center" style="color:#00008b;font-size:1rem;font-weight:bold">Lucrative Returns on Social Investment.</p>
                         <center> <a href="https://ultimatebliss.in/Ultimate/investor_invited" style="background:#ffb300 " class="btn btn-primary btn-center mt-3 mb-3">Click for details</a></center>
                     </div>
                 </div>
             </div>
             <div class="col-md-6 col-lg-6">
                 <div class="card" style="width: 100%;">
                     <img src="https://ultimatebliss.in/assets/responsiveimg/20.jpg" class="card-img-top" height="250h" alt="...">
                     <div class="card-body">
                         <h4 class="card-title text-center text-uppercase mt-3 mb-5" style="color:#ff0090;font-size:1.4rem;font-weight:bold">Ultimate Bliss Ambassador Program</h4>
                         <p class="card-text text-center" style="color:#00008b;font-size:1rem;font-weight:bold">Earn Money from Home without any investment</p>
                         <center> <a href="https://ultimatebliss.in/Ultimate/ambassador_program" style="background:#ffb300 " class="btn btn-primary btn-center mb-3 mt-3">Click for details</a></center>
                     </div>
                 </div>
             </div>
         </div>

         <h3 class="text-center" style="color:#ff0090;margin-bottom:-9rem;margin-top:5rem;font-weight:bold">What is Real Freedom?</h3>
         <div class="main-heading pb-5 pl-5 pr-5" style="padding-top:7rem">
             <h6>
                 “When our consciousness is not absorbed or engaged compulsively in thoughts, emotions, memories, desires, planning, imagination, physical sensations, physical & mental actions, mental conditioning etc, this is the moment of real freedom. Real freedom is possible only in the state of total awakening. <br><br>
                 Only in the state of Real Freedom Ultimate Intelligence & Wisdom, Ultimate Bliss of Existence and Ultimate Being can be realized.” Swami Aaron (Dr. Aaron Thomas)

             </h6>
         </div>
     </div>


     <section class="container spacing">
         <div class="elevin-section container">
             <div class="elevin-section-one" style="background:#ebfbcd;box-shadow:0px 1px 2px 2px grey">
                 <h2 class="elevin-h2" style="color:#ff0090;font-weight:bold">Testimonials</h2>
                 <div class="elevin-center-img text-center">
                     <img src="https://ultimatebliss.in/assets/images/bhawna.jpg" alt="anjali" class="elevin-img center">
                 </div>
                 <h2 class="elevin-name" style="color:#ff0090;font-weight:bold">Bhawna Madan</h2>
                 <div class="elevin-star mb-2">

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                 </div>
                 <p class="elevin-para" style="color:#00008b;font-size:1.3rem;line-height:40px;font-weight:bold;  text-align: justify;
  text-justify: inter-word;">After my divorce I was in horrible depression. I was searching for doctors in my
                     nearby area on internet and came across website UltimateBliss.in. The name it-self stroked me and I
                     scrolled through the website and finally I contacted Swami Aaron telephonically. He agreed to give
                     me treatment. I had regular sessions with him for near-about four to five months. Today, I am not
                     only free from depression, rather I am very blissful just because of Swami ji’s teaching to me on
                     consciousness. Now, I am more mindful and really happy from inside. He mentally prepared me for my
                     marriage through his psychological and spiritual training and today I am living a happily married
                     life. I will be always grateful to Swami Ji for my whole life.</p>
             </div>

             <div class="elevin-section-one" style="background:#ebfbcd;box-shadow:0px 1px 2px 2px grey">

                 <h2 class="elevin-h2" style="color:#ff0090;font-weight:bold">Testimonials</h2>



                 <div class="elevin-center-img text-center">

                     <img src="https://ultimatebliss.in/assets/images/anjali.jpg" alt="Sneha" class="elevin-img center">

                 </div>



                 <h2 class="elevin-name" style="color:#ff0090;font-weight:bold">Sneha</h2>



                 <div class="elevin-star mb-3">

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                 </div>

                 <p class="elevin-para" style="color:#00008b;font-size:1.3rem;line-height:40px;font-weight:bold;  text-align: justify;
  text-justify: inter-word;">I have been facing the problems of severe pain in different parts of my body
                     since I was of 17 years. I had consulted to so many doctors, but all proved futile. </p>
                 <p class="elevin-para" style="color:#00008b;font-size:1.3rem;line-height:40px;font-weight:bold;  text-align: justify;
  text-justify: inter-word;">Then I don’t know how I got in contact with Dr. Aaron Thomas. When I met him,
                     then I came to know that I had the problem of Fibromyalgia. I started taking alternative treatments
                     from him for near about 6 to 7 months and now I am almost free from all those pain. </p>

             </div>

             <div class="elevin-section-one" style="background:#ebfbcd;box-shadow:0px 1px 2px 2px grey">

                 <h2 class="elevin-h2" style="color:#ff0090;font-weight:bold">Testimonials</h2>



                 <div class="elevin-center-img text-center">

                     <img src="https://ultimatebliss.in/assets/images/somnath-singh.jpg" alt="somnath-singh" class="elevin-img center">

                 </div>



                 <h2 class="elevin-name" style="color:#ff0090;font-weight:bold">Somnath Singh</h2>



                 <div class="elevin-star mb-3">

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                 </div>

                 <p class="elevin-para" style="color:#00008b;font-size:1.3rem;line-height:40px; font-weight:bold; text-align: justify;
  text-justify: inter-word;">After collapse of my business, I went in deep depression. One day I saw and
                     advertisement of Swami Ji on Facebook and contacted him. He gave me treatment and moreover he taught
                     me the Science of Spiritual Healing. I am not only free from all tension, depression etc., rather I
                     myself have become a pranic healer just because of the Swami Ji’s training. </p>

             </div>

             <div class="elevin-section-one" style="background:#ebfbcd;box-shadow:0px 1px 2px 2px grey">

                 <h2 class="elevin-h2" style="color:#ff0090;font-weight:bold">Testimonials</h2>



                 <div class="elevin-center-img text-center">

                     <img src="https://ultimatebliss.in/assets/images/shashank.jpg" alt="shashank" class="elevin-img center">

                 </div>



                 <h2 class="elevin-name" style="color:#ff0090;font-weight:bold">Shashank Saha</h2>



                 <div class="elevin-star mb-3">

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                 </div>

                 <p class="elevin-para" style="color:#00008b;font-size:1.3rem;line-height:40px; font-weight:bold; text-align: justify;
  text-justify: inter-word;">I had the attention deficit problem. Whenever I would sit for study, so many
                     thought would come and sway me away. I was never able to concentrate on my study. Then, I approached
                     to Dr. Aaron and had sessions from him for two months. He taught me several techniques and made me
                     practice them. Gradually I was able to enhance my concentration power and now am totally free from
                     my problems. I scored 97% in my higher secondary examination.</p>

             </div>

             <div class="elevin-section-one" style="background:#ebfbcd;box-shadow:0px 1px 2px 2px grey">

                 <h2 class="elevin-h2" style="color:#ff0090;font-weight:bold">Testimonials</h2>



                 <div class="elevin-center-img text-center">

                     <img src=" https://ultimatebliss.in/assets/images/Alex.jpeg" alt="Alex" class="elevin-img center">

                 </div>



                 <h2 class="elevin-name" style="color:#ff0090;font-weight:bold">Alex</h2>



                 <div class="elevin-starv mb-3">

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                     <i style="color:black;" class="fas fa-star"></i>

                 </div>

                 <p class="elevin-para" style="color:#00008b;font-size:1.3rem;line-height:40px;font-weight:bold;  text-align: justify;
  text-justify: inter-word;">I want to tell you how grateful I am to Swami Aaron. It is very rare luck - to find such enlightened person as he, he did a lot for me, for which I am very appreciative for him. And I also advise you to touch the benefits of knowledge and enlightenment that he can really help you to get.</p>

             </div>

             <!--<div class="dotdown" style="text-align:center">-->

             <!--    <span class="dot"></span>-->
             <!--    <span class="dot"></span>-->
             <!--    <span class="dot"></span>-->
             <!--    <span class="dot"></span>-->
             <!--    <span class="dot"></span>-->

             <!--</div>-->
         </div>
     </section>



     <section style="background-color:#33cccc ; padding-top:60px;">
         <div class="container ">

             <div class="row ">
                 <div class="col-md-12">
                     <div class="footer text-center ">

                         <h6 class="footer " style="color: #00008b; line-height: 1.7;font-size:1.3rem">Website designed and developed by BRAND PROMOTER INCORPORATION
                             <br>
                             Copyright 2021© Aaron Thomas
                         </h6>


                         <div class="list-footer pb-3 ">

                             <a href="privacy-policy.php" class="btns" style="color:#ff0090;font-size:1.2rem">Privacy Policy</a>&nbsp;|&nbsp;
                             <a href="#" class="btns" style="color:#ff0090 ;font-size:1.2rem">Terms & Condition</a>&nbsp;|&nbsp;
                             <a href="refund-policy.php" class="btns" style="color:#ff0090 ;font-size:1.2rem"> Refund Policy</a>&nbsp;|&nbsp;
                             <a href="site-map.php" class="btns" style="color:#ff0090;font-size:1.2rem ">Sitemap</a>

                         </div>


                     </div>
                 </div>
             </div>
     </section>
     <script>
         let slideIndex = 0;

         showSlides();



         function showSlides() {

             let i;

             let slides = document.getElementsByClassName("elevin-section-one");

             let dots = document.getElementsByClassName("dot");

             for (i = 0; i < slides.length; i++) {

                 slides[i].style.display = "none";

             }

             slideIndex++;

             if (slideIndex > slides.length) {
                 slideIndex = 1
             }

             for (i = 0; i < dots.length; i++) {

                 dots[i].className = dots[i].className.replace(" active", "");

             }

             slides[slideIndex - 1].style.display = "block";

             dots[slideIndex - 1].className += " active";

             setTimeout(showSlides, 5000); // Change image every 2 seconds

         }
     </script>

     <script>
         let slide = 0;

         show();



         function show() {

             let i;

             let slides = document.getElementsByClassName("youtube-section-one");

             let dots = document.getElementsByClassName("dot");

             for (i = 0; i < slides.length; i++) {

                 slides[i].style.display = "none";

             }

             slide++;

             if (slide > slides.length) {
                 slide = 1
             }

             for (i = 0; i < dots.length; i++) {

                 dots[i].className = dots[i].className.replace(" active", "");

             }

             slides[slide - 1].style.display = "block";

             dots[slide - 1].className += " active";

             setTimeout(show, 5000); // Change image every 2 seconds

         }
     </script>
     <script scr="https://ultimatebliss.in/assets/homeassets/fontawesome.js"></script>

     <script scr="https://ultimatebliss.in/assets/homeassets/popper.min.js"></script>




     <!-- Google recaptcha API library -->
     <script src="https://www.google.com/recaptcha/api.js" async defer></script>

     <!-- Latest compiled JavaScript -->
     <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script> -->
     </div>
 </body>

 </html>